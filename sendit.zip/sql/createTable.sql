CREATE TABLE `SendItDB`.`UserLogIn`
(`emailAddress` VARCHAR
(50), `password` VARCHAR
(50),`FirstName` VARCHAR
(50),`LastName` VARCHAR
(50),`WithAddress` VARCHAR
(5), PRIMARY KEY
(`emailAddress`))